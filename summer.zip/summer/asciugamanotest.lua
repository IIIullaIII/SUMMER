
    
    local Asciugamano_list = {
	{ "Red Asciugamano", "red"},
	{ "Orange Asciugamano", "orange"},
    { "Black Asciugamano", "black"},
	{ "Yellow Asciugamano", "yellow"},
	{ "Green Asciugamano", "green"},
	{ "Blue Asciugamano", "blue"},
	{ "Violet Asciugamano", "violet"},
}

for i in ipairs(Asciugamano_list) do
	local asciugamanodesc = Asciugamano_list[i][1]
	local colour = Asciugamano_list[i][2]
    local function reg_asciugamano(color)

	
--local asciugamano_item_name = "summer:asciugamano_"..colour.."_item"
--	local asciugamano_ent_name = "summer:asciugamano_"..colour.."_entity"
  
minetest.register_node("summer:asciugamano_"..colour.."", {
	    description = asciugamanodesc.."",
	    drawtype = "mesh",
		mesh = "asciugamano.obj",
	    tiles = {"asciugsmano_"..colour..".png",
	    },	    
        inventory_image = "asciugsmano_a_"..colour..".png",
	    
        wield_image  = {"asciugsmano_a_"..colour..".png",
	    },
	    paramtype = "light",
	    paramtype2 = "facedir",
	    sunlight_propagates = true,
	    walkable = false,
	    selection_box = {
	        type = "fixed",
	        fixed = { -1.0, -0.5,-0.5, 1.0,-0.49, 0.5 },
	    },
		groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3,not_in_creative_inventory=0},
		--sounds = default.node_sound_wood_defaults(),
        drop = "summer:asciugamano_"..colour.."",        
		--on_rightclick = default.player_set_animation(clicker, "lay" , 30)
        
 
   })
  --[[ minetest.register_entity("summer:asciugamano_"..colour.."", asciugamano)
   local asciugamano = {
	physical = true,
	collisionbox = {-1.0, -0.5,-0.5, 1.0,-0.49, 0.5},
	visual = "mesh",
	mesh = "asciugamano.obj",
	--textures = { "asciugsmano_"..colour..".png" },
    tiles = {"asciugsmano_"..colour..".png",
	    },	    
        inventory_image = "asciugsmano_a_"..colour..".png",
	    
        wield_image  = {"asciugsmano_a_"..colour..".png",
	    },
	    paramtype = "light",
	    paramtype2 = "facedir",
	    sunlight_propagates = true,
	    walkable = false,
	    selection_box = {
	        type = "fixed",
	        fixed = { -1.0, -0.5,-0.5, 1.0,-0.49, 0.5 },
	
}
   }]]
   function asciugamano.on_rightclick(self, clicker)
	if not clicker or not clicker:is_player() then
		return
	end
	local name = clicker:get_player_name()
	if  clicker == clicker then
        clicker:set_attach(self.object, "",
			{x = 0, y = 11, z = -3}, {x = 0, y = 0, z = 0})
		default.player_attached[name] = true
		minetest.after(0.2, function()
			default.player_set_animation(clicker, "lay" , 30)
		end)

	minetest.register_craft({
		output = "summer:asciugamano_"..colour.."",
		recipe = {
			{"","","", },
			{"wool:"..colour, "", "", },
			{"cannabis:canapa_fiber", "cannabis:canapa_fiber", "cannabis:canapa_fiber", }
		}
	})
	
end
   end
   end
end
