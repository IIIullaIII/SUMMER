     summer_music={} --This is needed because you cannot save the handle of the sound in param2 of the node

    minetest.register_node("summer:musicblock", {
        description = "Music Block",
        tile_images = {"default_wood.png"},
        groups = {snappy=2,choppy=2,oddly_breakable_by_hand=2},
    })


    --Some functions that you need to save the handle in summer_music:
    function summer_get_handle(pos)
        local i=0
        while summer_music[i]~=nil do
            if summer_music[i].pos.x==pos.x and summer_music[i].pos.y==pos.y and summer_music[i].pos.z==pos.z then
                return summer_music[i].handle
            end
            i=i+1
        end
        return 0
    end

    function summer_set_handle(pos, handle)
        local i=0
        while summer_music[i]~=nil do
            if summer_music[i].pos.x==pos.x and summer_music[i].pos.y==pos.y and summer_music[i].pos.z==pos.z then
                summer_music[i].handle=handle
                return
            end
            i=i+1
        end
        summer_music[i]={}
        summer_music[i].pos=pos
        summer_music[i].handle=handle
    end


    --This is the actual code that plays the sound:
    minetest.register_on_punchnode(function(pos, node, puncher)
        if node.name=="summer:musicblock" then
            if summer_get_handle(pos)==0 then
                local handle=0
                handle = minetest.sound_play("porta_ch.ogg", { --name of sound, file name extension is .ogg
                pos = pos, --pos where sound comes from
                gain = 1.0,
                max_hear_distance = 32,}) --sound gets lower the farer you get away from the jukebox
                summer_set_handle(pos, handle)
            else
                minetest.sound_stop(summer_get_handle(pos))
                summer_set_handle(pos, 0)
            end
        end
    end)
