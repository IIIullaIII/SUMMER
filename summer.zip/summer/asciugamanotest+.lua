
    
    local Asciugamano_list = {
	{ "Red Asciugamano", "red"},
	{ "Orange Asciugamano", "orange"},
    { "Black Asciugamano", "black"},
	{ "Yellow Asciugamano", "yellow"},
	{ "Green Asciugamano", "green"},
	{ "Blue Asciugamano", "blue"},
	{ "Violet Asciugamano", "violet"},
}


for i in ipairs(Asciugamano_list) do
	local asciugamanodesc = Asciugamano_list[i][1]
	local colour = Asciugamano_list[i][2]
   
    

      
minetest.register_globalstep(function(dtime)
	local players = minetest.get_connected_players()
	for i=1, #players do
		local name = players[i]:get_player_name()
		if default.player_attached[name] and not players[i]:get_attach() and
				(players[i]:get_player_control().up == true or
				players[i]:get_player_control().down == true or
				players[i]:get_player_control().left == true or
				players[i]:get_player_control().right == true or
				players[i]:get_player_control().jump == true) then
			players[i]:set_eye_offset({x=0, y=0, z=0}, {x=0, y=0, z=0})
			players[i]:set_physics_override(0, 0, 0)
			default.player_attached[name] = true
			default.player_set_animation(players[i], "lay", 30)
		end
	end
end)
   minetest.register_node("summer:asciugamano_"..colour.."", {
	    description = asciugamanodesc.."",
	    drawtype = "mesh",
		mesh = "asciugamano.obj",
	    tiles = {"asciugsmano_"..colour..".png",
	    },	    
        inventory_image = "asciugsmano_a_"..colour..".png",
	    
        wield_image  = {"asciugsmano_a_"..colour..".png",
	    },
	    paramtype = "light",
	    paramtype2 = "facedir",
	    sunlight_propagates = true,
	    walkable = false,
	    selection_box = {
	        type = "fixed",
	        fixed = { -1.0, -0.5,-0.5, 1.0,-0.49, 0.5 },
	    },
		groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3,not_in_creative_inventory=0},
		--sounds = default.node_sound_wood_defaults(),
        drop = "summer:asciugamano_"..colour.."", 
       

        
on_rightclick = function(pos, node, player, itemstack, pointed_thing) 
      
   
		
		if default.player_attached[name] then
			player:set_eye_offset({x=0, y=0, z=0}, {x=0, y=0, z=0})
			player:set_physics_override(1, 1, 1)
			default.player_attached[name] = false
			default.player_set_animation(player, "stand", 30)
		else
			player:set_eye_offset({x=0, y=-13, z=0}, {x=0, y=0, z=0})
			player:set_physics_override(0, 0, 0)
			default.player_attached[name] = true
			default.player_set_animation(player, "lay", 0)
		end
	end
		--on_rightclick = default.player_set_animation(clicker, "lay" , 30)
        
    })

	minetest.register_craft({
		output = "summer:asciugamano_"..colour.."",
		recipe = {
			{"","","", },
			{"wool:"..colour, "", "", },
			{"cannabis:canapa_fiber", "cannabis:canapa_fiber", "cannabis:canapa_fiber", }
		}
	})
	
end
