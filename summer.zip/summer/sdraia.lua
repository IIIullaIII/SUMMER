local Sdraia_list = {
	{ "Red Sdraia", "red"},
	{ "Orange Sdraia", "orange"},
    { "Black Sdraia", "black"},
	{ "Yellow Sdraia", "yellow"},
	{ "Green Sdraia", "green"},
	{ "Blue Sdraia", "blue"},
	{ "Violet Sdraia", "violet"},
}

for i in ipairs(Sdraia_list) do
	local sdraiadesc = Sdraia_list[i][1]
	local colour = Sdraia_list[i][2]

    

minetest.register_node("summer:sdraia_"..colour.."", {
	    description = sdraiadesc.." summer",
	    drawtype = "mesh",
		mesh = "sdraia.obj",
	    tiles = {"sdraia_"..colour..".png",
	    },	
        inventory_image = "sdraia_"..colour.."_inv.png",
	    
        wield_image  = {"sdraia_"..colour.."_inv.png",
	    },
	    paramtype = "light",
	    paramtype2 = "facedir",
	    sunlight_propagates = true,
	    walkable = false,
	    selection_box = {
	        type = "fixed",
	        fixed = { -0.5, -0.5, -0.5, 0.5,0.0, 0.5 },
	    },
		groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3, not_in_creative_inventory=0},
		--sounds = default.node_sound_glass_defaults(),
		drop = "summer:sdraia_"..colour,
		--on_rightclick = function(pos, node, clicker, itemstack, pointed_thing)
			--	return 
			--end
	})


	minetest.register_craft({
		output = "summer:sdraia_"..colour.."",
		recipe = {
			{"", "wool:"..colour, "", },
			{"cannabis:canapa_fiber", "cannabis:canapa_plastic", "cannabis:canapa_fiber", },
			{"", "cannabis:canapa_fiber", "", }
		}
	})
	end
